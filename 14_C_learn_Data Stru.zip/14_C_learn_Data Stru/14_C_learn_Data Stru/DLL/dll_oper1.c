/* ********************************************************************
FILE                   : dll_oper1.c

PROGRAM DESCRIPTION    : ordered double linked list with operations of
                         insert, delete, display and search operations of nodes in
                         double linked list. 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  with more features added with base code from present dir->dll_oper.c
                         Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* INSERT   */ 
#define INSERT       (1) 
/* TRAVERSE */
#define DISP         (2) 
/* SEARCH   */
#define SEARCH       (3) 
/* DELETE   */
#define DEL          (4) 
/* QUIT     */
#define QUIT         (5) 
/* transverse forward dir */
#define FORWARD      (6)
/*transverse backward dir  */
#define BACKWARD     (7)
/* dll is empty */
#define EMPTY        (8)
/* front */
#define FRONT        (9)
/* rear */
#define REAR        (10)

#define MIN_DLL_INPUT_VAL           (-10000)
#define MAX_DLL_INPUT_VAL           (10000)
#define MAX_STR_LEN                 (10)

#define INVALID_NUM           (MIN_DLL_INPUT_VAL  - 1)
#define CAN_BEGIN_SIGN        (1)
#define CANNOT_USE_SIGN       (2)
#define DLL_VAL_SIGN          CAN_BEGIN_SIGN 

typedef struct NODE
 {
                     struct NODE *fwd;
                     struct NODE *bwd;
                     int value;
 } Node;
 typedef struct input_data
 {
  	size_t input_data_len;
 	int req_sign;
 	int min_val_input_data;
 	int max_val_input_data;
 	char str_data_input[MAX_STR_LEN];
 } input_data_fmt;
 
/* function declarations */
void Traverse_Fwd_DLL (Node *);
void Traverse_Bwd_DLL (Node *);
void Insert_Fwd_DLL ( Node *, const int);
void Insert_Bwd_DLL ( Node *, const int);
Node *Search_Fwd_DLL (Node *, const int);
Node *Search_Bwd_DLL (Node *, const int);
void Delete_Fwd_DLL (Node *, const int);
void Delete_Bwd_DLL ( Node *, const int);
void Delete_All_DLL (Node *);
int Oper_DLL(Node *, const int );
int Validate_Int_Input(const input_data_fmt *const );
int Get_Value_DLL(input_data_fmt *const cur_input_data_ptr);

int main(void)
{
    Node root;     /* root is a Node, not a pointer to Node */
    input_data_fmt cur_input_data;  
    int op = 0;
    int value = 0;
    int dll_status = 0; /* dll_status */
     
    /* fwd and bwd fields of root set to NULL, fwd of root node is root for forward direction and bwd of root node is root for backward direction */
    root.fwd = 0;
    root.bwd = 0;
    root.value = 0; /* num of nodes in dll for root node */
    
    printf("\n**Program Shows different operations on Doubly Linked "
           "List.**\n");
   printf("\n User, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - DEL, 5 - QUIT: "); 
    while (1)
	 {
          gets(cur_input_data.str_data_input);
          cur_input_data.input_data_len = strlen(cur_input_data.str_data_input);
          cur_input_data.min_val_input_data = INSERT;
          cur_input_data.max_val_input_data = QUIT;
          cur_input_data.req_sign = CANNOT_USE_SIGN;
          op = Validate_Int_Input(&cur_input_data );
          
		        switch (op)
				{
					case DISP:
				       Traverse_Fwd_DLL(&root);
				    break;
					case INSERT:   
                       printf("User, enter integer value to insert: ");
                       value = Get_Value_DLL(&cur_input_data);
                       if(value == INVALID_NUM)
                       {
                       	   break;
					   }
				       dll_status = Oper_DLL(&root, value);                
                       switch(dll_status)
					   {
					     	case FORWARD:
					     	case EMPTY:
							case FRONT: 	
					     	     Insert_Fwd_DLL(&root, value);
						    break;  
                            case BACKWARD:
                            case REAR: 	
                               Insert_Bwd_DLL(&root, value);
                            break;  
				            default:
                        	    printf("Incorrect dll status \n");
                        	break;
					    }    
                    break;
                    case SEARCH:
				        printf("User, enter an integer value to search : ");
                        value = Get_Value_DLL(&cur_input_data);
                        if(value == INVALID_NUM)
                        {
                       	   break;
					    }
				        dll_status = Oper_DLL(&root, value);                
                        switch(dll_status)
					    {
					     	case FORWARD:					       	
						       Search_Fwd_DLL(&root, value);
						    break;  
                            case BACKWARD:
                               Search_Bwd_DLL(&root, value);
                            break; 
							case EMPTY:
							    printf("\aEmpty list \n");
                            break; 
                            case FRONT:
							case REAR:
							   	 printf("\a value = %d not found \n", value);
							break;   	 
				            default:
                        	    printf("Incorrect dll status \n");
                            break;
					    }    
                    break;                
                    case  DEL:
                    	printf("User, enter an integer value to delete : ");
                        value = Get_Value_DLL(&cur_input_data);
                        if(value == INVALID_NUM)
                        {
                       	   break;
					    }
				        dll_status = Oper_DLL(&root, value);                
                        switch(dll_status)
					    {
					     	case FORWARD:
						       Delete_Fwd_DLL(&root, value);
						    break;  
                            case BACKWARD:
                               Delete_Bwd_DLL(&root, value);
                             break;
							case EMPTY:
							    printf("\aEmpty list \n");
                            break; 
                            case FRONT:
							case REAR:
							   	 printf("\a value = %d not found \n", value);
							break;     
				            default:
                        	    printf("Incorrect dll status \n");
                        	 break;
					    }    
                    break;          
				    case  QUIT:
			    		 Delete_All_DLL(&root);
                         printf("\n Thank You!\n");
                         exit(0);
                     break;
					 default:
					   	printf("Incorrect menu entered \n");
					   	break;
				}
                printf("\n User, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - DEL, 5 - QUIT: ");
           }
}
 
void Insert_Fwd_DLL(register Node *p2r, const int value)
{
    register Node *this_node = p2r;
    register Node *next;
    register Node *newnode;
 
    /* Let's confirn if value is already in the  list */
    while ((next = this_node->fwd) != NULL)
	 {
	 	 /* I ensure each value is inserted once */
            if (next->value == value)
			 {
                    printf("\aValue %d is already in the list!\n", next->value);
                    return ;
            } 
		    if (next->value > value)
                    break;                     
            this_node = next;
           	printf("value = %d, this_node = %p, next = %p\n", this_node->value, this_node, next );   
    }
 
    /* Value isn't already in the list */
    /* Let's allocate it in proper place in the list */
    /* Allocate space to newnode */
    newnode = (Node *)malloc(sizeof(Node));
 
    /* Verify if allocation successful */
    if (newnode == NULL) 
	{
        printf("Error: Memory Allocation Failed!\n");
        exit(EXIT_FAILURE);
    }
 
    /* write in value in the newnode */
    newnode->value = value;
 
    /* Insert value in the list */
    /* 
     * four pointer fields in this_node, newnode and next required
     * to be adjusted
     */
    newnode->fwd = next;
    this_node->fwd = newnode;
 
    if (this_node != p2r)
        newnode->bwd = this_node;
    else
    /* newnode is only node in dll */
        newnode->bwd = NULL;
 
    if (next != NULL)
        next->bwd = newnode;
    else
     /* newnode is end node in dll */
        p2r->bwd = newnode;
    ++p2r->value;
    printf("nos node = %d, Value %d at node %p, prev = %p, next = %p\n", p2r->value, value, newnode, newnode->bwd, newnode->fwd);
}


 void Insert_Bwd_DLL(register Node *p2r, const int value)
{
    register Node *this_node = p2r;
    register Node *prev;
    register Node *newnode;
 
    /* Let's confirn if value is already in the  list */
    while ((prev = this_node->bwd) != NULL)
	 {
	 	 /* I ensure each value is inserted once */
            if (prev->value == value)
			 {
                    printf("\aValue %d is already in the list!\n", prev->value);
                    return ;
            } 		         
            if (prev->value < value)
                    break;                     
            this_node = prev;
           	printf("value = %d, this_node = %p, prev = %p\n", this_node->value, this_node, prev );  
    }
 
    /* Value isn't already in the list */
    /* Let's allocate it in proper place in the list */
    /* Allocate space to newnode */
    newnode = (Node *)malloc(sizeof(Node));
 
    /* Verify if allocation successful */
    if (newnode == NULL) 
	{
        printf("Error: Memory Allocation Failed!\n");
        exit(EXIT_FAILURE);
    }
 
    /* write in value in the newnode */
    newnode->value = value;
 
    /* Insert value in the list */
    /* 
     * four pointer fields in this_node, newnode and next required
     * to be adjusted
     */
    newnode->bwd = prev;
    this_node->bwd = newnode;
 
    if (this_node != p2r)
        newnode->fwd = this_node;
    else
    /* newnode is only node in dll */
        newnode->fwd = NULL;
 
    if (prev != NULL)
        prev->fwd = newnode;
    else
     /* newnode is first node in dll */
        p2r->fwd = newnode;
 
    ++p2r->value;
    printf("nos node = %d, Value %d at node %p, prev = %p, next = %p\n", p2r->value, value, newnode, newnode->bwd, newnode->fwd);
}


void Traverse_Fwd_DLL(register Node *p2r)
{
    register Node *this_node = p2r->fwd;
    size_t nodes = 0; 
   
    /* List isn't EMPTY, Traversing the list in FORWARD direction */    
    printf("\nList is as follows: \n");
    while (this_node != NULL)
	{
	     printf("value = %d , this_node = %p, prev = %p, next = %p\n", this_node->value, this_node, this_node->bwd, this_node->fwd);
         this_node = this_node->fwd;
         ++nodes;
    }
    if(nodes == p2r->value)
       printf("nos of nodes = %d",p2r->value );
	else
	  printf("\n \a nos nodes not matched");           
}
 
void Traverse_Bwd_DLL(register Node *p2r)
{
    register Node *this_node = p2r->bwd;
   	size_t nodes = 0; 
   	
    /* List isn't EMPTY, Traversing the list in Backward direction */
    printf("\nList is as follows: \n");
    while (this_node != NULL) 
	{
	       printf("value = %d , this_node = %p, prev = %p, next = %p\n", this_node->value, this_node, this_node->bwd, this_node->fwd); 
           this_node = this_node->bwd;
            ++nodes;
    }
    if(nodes == p2r->value)
       printf("nos of nodes = %d",p2r->value );
	else
	  printf("\n \a nos nodes not matched");    
}
 
void Delete_Fwd_DLL(register Node *p2r, const int value)
{
    register Node *prev = p2r;
    register Node *next;
    register Node *dnode;
    
        /*
         * List isn't empty. We search through the entire list for 
         * desired value and once found, we'll delete the node containing
         * the value
         */
        while ((dnode = prev->fwd) != NULL && dnode->value != value)
                prev = dnode; /* update the current node */
 
        /* now there are 2 cases, Either we've reached the end of list */
        if (dnode == NULL) 
		{
           printf("We have reached the end of the List.\n");
           printf("Value %d is NOT in the list.\n", value);
           return ;
        }
        
          /*  * set fwd to node following node to be deleted  */
          prev->fwd = dnode->fwd;
 
         next = dnode->fwd;
         if (next == NULL)
		  {
                 /* reached end of list */
                 /* 
                   * set bwd field of root node to preceding node 
                   * of deleting node
                  */
                 p2r->bwd = dnode->bwd;
           }
           else
		    {
                  /* else where in the list */
                  next->bwd = dnode->bwd;
            }
             --p2r->value; 
             printf("deleted value = %d at node %p, prev = %p, next = %p\n", value, dnode, dnode->bwd, dnode->fwd);
             printf("nos of nodes = %d \n", p2r->value);
             /* now free up the dnode */
            free(dnode);
            return ;
  
}


void Delete_Bwd_DLL(register Node *p2r, const int value)
{
    register Node *prev ;
    register Node *next = p2r;
    register Node *dnode;
     
        /*
         * List isn't empty. We search through the entire list for 
         * desired value and once found, we'll delete the node containing
         * the value
         */
        while ((dnode = next->bwd) != NULL && dnode->value != value)
                next = dnode; /* update the next node */
 
        /* now there are 2 cases, Either we've reached the end of list */
        if (dnode == NULL) 
		{
           printf("We have reached the end of the List.\n");
           printf("Value %d is NOT in the list.\n", value);
           return ;
        }
        
          /*  * set bwd  to node following node to be deleted  */
          next->bwd = dnode->bwd; 
         
         prev = dnode->bwd;
         if (prev == NULL)
		  {
                 /* reached front of list */
                 /* 
                   * set fwd field of root node to preceding node 
                   * of deleting node
                  */
                 p2r->fwd = dnode->fwd;
           }
           else
		    {
                  /* else where in the list */
                  prev->fwd = dnode->fwd;
            }
             --p2r->value; 
             printf("deleted value = %d at node %p, prev = %p, next = %p\n", value, dnode, dnode->bwd, dnode->fwd);
             printf("nos of nodes = %d \n", p2r->value);
             /* now free up the dnode */
            free(dnode);
            return ;
  
} 

void Delete_All_DLL(register Node *root_ptr)
{
    Node *this_node = root_ptr->bwd;
    register Node *prev;
    
    if(this_node == NULL)
    {
    	printf("\n \a List is empty\n");
    	return;
	}
	while((this_node )  != NULL)
	{
	    printf("\n value = %d, free node : %p ", this_node->value, this_node );
	   	prev = this_node->bwd;
	   	free(this_node);
	   	this_node = prev;
	}
	root_ptr->fwd = NULL;
	root_ptr->bwd = NULL;
	root_ptr->value = 0;
}


Node *Search_Fwd_DLL(register Node *p2r, const int value)
{
    register Node *this_node = p2r->fwd;
   
     /* List isn't EMPTY, Searching value in the list */
     while ((this_node != NULL) && this_node->value != value)
          this_node = this_node->fwd;
 
            if (this_node == NULL)
			 {  /* reached end of list */
                printf("value = %d is NOT in the list.\n", value);                
            }
            else
            {
			    printf("value = %d at node %p \n", value, this_node);                
            }
            return this_node;       
  }
  
 Node *Search_Bwd_DLL(register Node *p2r, const int value)
{
    register Node *this_node = p2r->bwd;
     
     /* List isn't EMPTY, Searching value in the list */
     while ((this_node != NULL) && this_node->value != value)
          this_node = this_node->bwd;
 
            if (this_node == NULL)
			 {  /* reached end of list */
                printf("value = %d is NOT in the list.\n", value);                
            }
            else
            {
			    printf("value = %d at node %p \n", value, this_node);                
            }
            return this_node;       
  }
  
  
  int Oper_DLL(Node *root_ptr, const int value )
  {
  	  int  dll_status = 0;   	  
  	  Node *fwd_node = root_ptr->fwd;
  	  Node *bwd_node = root_ptr->bwd;
  	  
  	  /* empty list */
  	  if(fwd_node == NULL)
  	  {
  	  	  printf("\n oper = EMPTY LIST \n");
  	  	  return (dll_status = EMPTY); 
      }
      /* fwd root node value > value */
      if(fwd_node->value > value)
      {
      	   printf("\n oper = FRONT \n");
      	  return (dll_status = FRONT); 
	  }
	  
	  if(bwd_node->value < value )
	  {
	  	  printf("\n oper = REAR \n");
	  	  return (dll_status = REAR); 
	  }
	  
	  dll_status = (value - fwd_node->value <= bwd_node->value - value ) ? FORWARD : BACKWARD;
	  dll_status == FORWARD ?  printf("\n oper = FORWARD \n") :  printf("\n oper = BACKWARD \n");
	 
	  return dll_status;
  }
  
int Get_Value_DLL(input_data_fmt *const cur_input_data_ptr)
{
	int value;
	
    gets(cur_input_data_ptr->str_data_input);
    cur_input_data_ptr->input_data_len = strlen(cur_input_data_ptr->str_data_input);
    cur_input_data_ptr->min_val_input_data =  MIN_DLL_INPUT_VAL;
    cur_input_data_ptr->max_val_input_data = MAX_DLL_INPUT_VAL;
    cur_input_data_ptr->req_sign = DLL_VAL_SIGN;
    value = Validate_Int_Input(cur_input_data_ptr);	
    return value;
} 
 
int Validate_Int_Input(const input_data_fmt *const cur_data_ptr)
{
	char compare_string[cur_data_ptr->input_data_len + 1];
    int int_data_input, int_data_pos = 0;  	
	
	if(!(*cur_data_ptr->str_data_input >= '0' && *cur_data_ptr->str_data_input <= '9' || *cur_data_ptr->str_data_input == '+' || *cur_data_ptr->str_data_input == '-' ))
   	{
	   printf("\n \aERROR[03]: Starting letter is not a number or sign. \n ");
       return INVALID_NUM;			
    } 
	if(cur_data_ptr->req_sign == CAN_BEGIN_SIGN)
	{
		if( (*cur_data_ptr->str_data_input == '+' || *cur_data_ptr->str_data_input == '-') && cur_data_ptr->input_data_len == 1 )
    	{
	    	printf("\n \aERROR[05]: Invalid data input due to only sign\n");	
	        return INVALID_NUM;		
     	}
    	if((*cur_data_ptr->str_data_input == '+' || *cur_data_ptr->str_data_input == '-') && !(*(cur_data_ptr->str_data_input + 1) >= '0' && *(cur_data_ptr->str_data_input + 1) <= '9' ) )
    	{
	    	printf("\n \aERROR[06]: Invalid data input begins with sign but next character is a not a integer\n") ;	
	        return INVALID_NUM;
	    } 
    	if(*cur_data_ptr->str_data_input == '+' || *cur_data_ptr->str_data_input == '-' )
    	{
	    	int_data_pos = 1;			
	    }		
	}
	else 
	{
		if( (*cur_data_ptr->str_data_input  == '+' || *cur_data_ptr->str_data_input == '-'))
		{
			printf("\n \aERROR[07]: Starting letter is sign with no sign oper\n ");
            return INVALID_NUM;
		}	
	}
    int_data_input = atoi (cur_data_ptr->str_data_input + int_data_pos);
	itoa(int_data_input, compare_string, 10 );
     /* compare with converted string wth given data to check given data is an integer */
    if(strcmp(compare_string, cur_data_ptr->str_data_input + int_data_pos) != 0)
    {	
         printf("\n \aERROR[04]: Begins with number but has non integer characters\n");
		 return INVALID_NUM; 	
	}
	if(*cur_data_ptr->str_data_input == '-' && cur_data_ptr->req_sign == CAN_BEGIN_SIGN)
   	{
    	int_data_input = -int_data_input;
	}   
    if(int_data_input< cur_data_ptr->min_val_input_data  || int_data_input> cur_data_ptr->max_val_input_data)
    {
       printf("\n\a ERROR[02]: Invalid Number out of range [%d, %d]\n", cur_data_ptr->min_val_input_data , cur_data_ptr->max_val_input_data);   
	   return INVALID_NUM;				
    }  
    return int_data_input; 
}


