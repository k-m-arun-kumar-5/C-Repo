/* ********************************************************************
FILE                   : sll_unorder.c

PROGRAM DESCRIPTION    : creates a unordered single linked list with insert 
                         and display nodes of single linked list
                              

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/* create_sll.c -- */


#include <stdio.h>
#include <stdlib.h>
 
/* symbolic constants declared */
#define INSERT 1
#define DISP   2
#define QUIT   3
 
/* structure declaration */
typedef struct  NODE {
                      struct NODE *link;
                      int value;
        } Node;
 
Node *insert_sll(const int);
void disp_sll(Node *root);
void free_sll(Node *root);
Node *search_sll(Node *linkp, Node *endp, const int value);
 
int main(void)
{
    Node *root = 0;         /* root is set to NULL */
    Node *end = 0;     /* pointer-to-root */
        
    int value;
    int op;
    
    puts("\n**Let's create a Singly Linked List**\n");
    printf("\n root = %p", root);
    printf("\n User, enter 1 for INSERT, 2 for DISP, 3 for QUIT: ");
    while (1) {
        while (scanf("%d", &op) == 1 && (op == INSERT || op == DISP || op == QUIT ))
		 {
 
            switch(op)
            {
            	case INSERT:
			       printf("\n User, enter an integer value: ");
                   scanf("%d", &value);  
				   end = insert_sll(value);
                   if(root == NULL) 
				   {				   	     
				     	root = end; 
				   } 
                break;
                case DISP:
                   disp_sll(root); 
                break;    
				case QUIT:
				  free_sll(root);
				  printf("\n Thank You!\n");
                  return 0; 
            }
            printf("\nWant to insert more integer values,\nenter 1 "
                   "for INSERT, 2 for DISP , 3 for QUIT : ");
        }
            puts("Entered is a WRONG choice, enter 1 "
                 "for INSERT, 2 for DISP , 3 for QUIT");
    }
}
 
Node *insert_sll(const int value)
{
    static Node *end = 0;
    Node *newnode = 0;
    
    /* Let's create an unordered singly linked list with non unique value */   
    /* Let's allocate memory to newnode */
    newnode = (Node *)malloc(sizeof(Node));
 
    /* If memory allocated to newnode successfully */
    if (newnode == NULL)
	{
        printf("Not sufficient Memory!\n");
        exit(EXIT_FAILURE);
    }
    // insert newnode in the list at end of list 
    if(end  == NULL)
    {
    	end = newnode; 
        end->link = NULL;  
	}
	else
	{
	   end->link = newnode;
	   end = newnode;  
	   newnode->link = NULL; 	
	}
    // write in value in value field of newnode 
       newnode->value = value; 
    
     printf("\n end node = %p",end);    
	 return end; 
}

void disp_sll(Node *current)
{
    while((current) != NULL)
	{
		printf("\n value = %d, current = %p, next = %p", current->value, current, current->link);
		current = current->link;
   	}
}
Node *search_sll(Node *startp, Node *endp, const int value)
{
     Node *endp = lastp, *thisp = startp;
     
     if(lastp != NULL)
	 {
	 		//lastp must be a node of search sll
	 	endp = lastp->link;
	 }
	 while((thisp) != endp && thisp->value != value )	
     {
        printf("\n cmp value = %d at node %p",thisp->value, thisp );
		thisp = thisp->link;
	 }
	 
 	if(thisp == endp)
	{
	  	  printf("\n value = %d not found in nodes between [%p, %p]", value, startp, lastp);	  	  
	  	  return NULL;
	}
	printf("\n value = %d found at node = %p between[%p, %p]", thisp->value, thisp,startp, lastp ) ;
	return thisp;
	 
	 
}
void free_sll(Node *linkp)
{
	Node *current;
	while((current = linkp)  != NULL)
	{
	    printf("\n free node : %p, value = %d", current, current->value);
	   	linkp = current->link;
	   	free(current);
	}	
}
/* ascending sorting list using Selection Sort */
void sort_unorder_sll(Node **linkp)
{
    int temp;
    Node *current = *linkp;
    Node *next = current->link;
 
    /* Let's sort the list by sorting values  */
    while (current->link != NULL)
	 { /* Outer while loop terminates when */
            /* there's no next node to current node in the list */
            while (next != NULL)
			 {  /* Inner while loop */
                    /* sorts the current value */
                    if (current->value > next->value)
					 {
                            /* swap the values */
                            temp = next->value;
                            next->value = current->value;
                            current->value = temp;
                    }
                    /* update the next value */
                    next = next->link;
            }
            /* current value is sorted */
            /* update the current and next values */
            current = current->link;
            next = current->link;
    }
}

